import './App.css';
function pag() {
  return (
    <a>uepa</a>
  );
}
export default pag;